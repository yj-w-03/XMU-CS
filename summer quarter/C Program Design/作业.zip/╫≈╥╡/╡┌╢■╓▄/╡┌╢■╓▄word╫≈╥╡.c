//1.
#include<stdio.h>
int main()
{
    char *p="I love China!";
    printf("%s",p);
    return 0;
}

//2.
#include<stdio.h>
#include<string.h>
int main()
{
    char *a="I am student";
    char b[100];
    strcpy(b,a);
    printf("%s",b);
    return 0;
}

//3.
#include<stdio.h>
#include<string.h>
int main()
{
    char a[100]="I love ";
    char b[100]="China";
    strcat(a,b);
    printf("%s",a);
    return 0;
}

//4.
#include<stdio.h>
#include<string.h>
int main()
{
    char a[100]="I love China!";
    char *p;
    for(p=a;*p!='\0';p++);
    p--;
    for(;p>=a;p--)//�������
        printf("%c",*p);
    return 0;
}

//5.
#include<stdio.h>
#include<string.h>
int main()
{
    char a[100];
    int count=0,i=0;
    gets(a);
    while(a[i]!='\0')//ͳ�����ָ���
    {
        if(a[i]>='0'&&a[i]<='9')
            {
                count++;
                printf("%c ",a[i]);
            }
            i++;
    }
    printf("\n");
    printf("%d",count);//�������
    return 0;
}

//6.
#include<stdio.h>
int main()
{
    char a[100];
    int count=0,i=0;
    gets(a);
    while(a[i]!='\0')//ͳ���ַ�����
    {
        if((a[i]>='A'&&a[i]<='Z')||(a[i]>='a'&&a[i]<='z'))
            {
                count++;
            }
            else  printf("%c",a[i]);//����മ
            i++;
    }
    printf("\n");
    printf("%d",count);
    return 0;
}

//7.
#include<stdio.h>
int main()
{
    char a[100];
    gets(a);
    int replace(char a[]);
    int result=replace(a);
    printf("%s\n",a);
    printf("%d",result);
    return 0;
}

int replace(char a[])
{
    int count=0,i=0;
    while(a[i]!='\0')
    {
        if((a[i]=='t')||(a[i]=='T'))//�����������������滻��ͳ��
            {
                if(a[i]=='t')
                {
                    count++;
                    a[i]='e';
                }
                else{
                    count++;
                    a[i]='E';
                }
            }
            i++;
    }
    return count;
}

//8.
#include<stdio.h>
int main()
{
    char a[20][20]={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
    int n;
    scanf("%d",&n);
    printf("%s\n",a[n-1]);
    return 0;
}

//9.
#include<stdio.h>
#include<string.h>
int main()
{
    char a[10][100],temp[100];
    int len[10],t,i,j;
    gets(a[0]);
    gets(a[1]);
    gets(a[2]);
    gets(a[3]);
    gets(a[4]);
    for(i=0;i<5;i++)
        len[i]=strlen(a[i]);
    for(i=0;i<5;i++)//���ַ�������С��������
        for(j=0;j<5-i-1;j++)
    {
        if(len[j]>len[j+1])
        {
            strcpy(temp,a[j]);
            strcpy(a[j],a[j+1]);
            strcpy(a[j+1],temp);
            t=len[j];len[j]=len[j+1];len[j+1]=t;
        }
    }
    for(i=0;i<5;i++)printf("%s\n",a[i]);
    for(i=0;i<5;i++)
    {
        if(len[i]<3)printf(" ");//���ַ���С��3����ո�
        else printf("%c",a[i][2]);
    }

    return 0;
}

//10.
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
void Swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

int main()
{
    int n;
    int *Arr = NULL;
    scanf("%d", &n);
    Arr = (int*)malloc(sizeof(int) * n);//���嶯̬����
    int i,j;
    srand((int) time(0));
    for(i = 0; i < n; i++)//�����ֵ
    {
        Arr[i] = rand();
    }
    for(i=0; i<n; i++)//������Ԫ�ؽ�������
        for(j=0; j<n-i-1; j++)
            if(Arr[j]<Arr[j+1])
            {
                Swap(&Arr[j],&Arr[j+1]);
            }
    for(int i=0; i<n; i++)
    {
        printf("%d ",Arr[i]);
    }
    free(Arr);
    return 0;
}
