//1.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
    int val;
    struct ListNode*next;
};

int main()
{
    struct ListNode *head,*p1,*p2;
    int n = 0, a[100],i;
	char c;
	while (1)//������������
	{
		scanf("%c", &c);
		if(c>=48&&c<=57)
            a[n]=c-48;
        else break;
        n++;
		scanf("%c", &c);
		if (c == '-') scanf("%c", &c);
		else break;
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	for (i=0; i < n; i++)//��������
	{
		if (i == 0)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
    struct ListNode*reverseList(struct ListNode*head);
    struct ListNode*p=reverseList(head);
    while(p!=NULL)//�������
    {
        printf("%d->",p->val);
        p=p->next;
    }
    printf("NULL");
    return 0;
}

struct ListNode*reverseList(struct ListNode*head)
{
    struct ListNode*cur,*pre,*temp;
    cur=head;pre=NULL;
    while(cur!=NULL)
    {
        temp=cur->next;//�ݴ���һ��
        cur->next=pre;//ָ��ǰһ��
        pre=cur;
        cur=temp;//�������±���
    }
    return pre;
}

//2.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
	int val;
	struct ListNode* next;
};

int main()
{
	struct ListNode* head = NULL, * p1, * p2;
	int n = 0, a[100],flag=0,i;
	char c;
	while (1)//������������
	{
		scanf("%d", &a[n]); n++;
		scanf("%c", &c);
		if (c == '-') scanf("%c", &c);
		else break;
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	head = NULL;
	for (i=0; i < n; i++)//��������
	{
		if (i == 0)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
	struct ListNode* deleteDuplicates(struct ListNode* head);
	struct ListNode* p = deleteDuplicates(head);
	while (p != NULL)//�������
	{
		if(flag==0)printf("%d", p->val);
		else
		printf("->%d", p->val);
		p = p->next;
		flag++;
	}
	return 0;
}

struct ListNode* deleteDuplicates(struct ListNode* head)
{
	struct ListNode* cur;
	cur = head;
	while (cur->next != NULL)
	{
		if (cur->val != cur->next->val)//������ظ��ͼ������±���
		{
			cur = cur->next;
		}
		else {
			cur->next = cur->next->next;//����ظ���ɾ���ظ����
		}
	}
	return head;
}

//3.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
	int val;
	struct ListNode* next;
};

int main()
{
	struct ListNode*head1 = NULL,*head2=NULL, * p1, * p2;
	int n = 0,m=0, a[100],b[100],c[100],flag=0,i;
	char ch;
	while (1)//�����һ����������
	{
	    scanf("%c", &ch);
	    if (ch == '-') scanf("%c", &ch);
	    if(ch==')')break;
		scanf("%d", &a[n]); n++;
	}
	scanf("%c",&ch);
	while (1)//����ڶ�����������
	{
	    scanf("%c", &ch);
	    if (ch == '-') scanf("%c", &ch);
	    if(ch==')')break;
		scanf("%d", &b[m]); m++;
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	for (i=0; i < n; i++)//������һ������
	{
		if (i == 0)head1 = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = b[0];
	for (i=0; i < m; i++)//�����ڶ�������
	{
		if (i == 0)head2 = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = b[i+1];
	}
	p2->next = NULL;
	struct ListNode* addTwoNumbers(struct ListNode* l1,struct ListNode* l2);
	struct ListNode* p = addTwoNumbers(head1,head2);
	while (p != NULL)//�������
	{
		if(flag==0)printf("%d", p->val);
		else
		printf("->%d", p->val);
		p = p->next;
		flag++;
	}
	return 0;
}

struct ListNode* addTwoNumbers(struct ListNode* l1,struct ListNode* l2)
{
	struct ListNode*p,*q,*head,*p1,*p2;
	int a1[100],b1[100],c1[100],n=0,m=0,i,j,r1=0,r2=0,r,t=1;
	p=l1;q=l2;
	while (p!=NULL)//�����һ����������
	{
		a1[n]=p->val;
		p=p->next;
		n++;
	}
	while (q!=NULL)//����ڶ�����������
	{
		b1[m]=q->val;
		q=q->next;
		m++;
	}
	for(i=0;i<n;i++)//�����һ����
    {
        r1+=a1[i]*t;
        t*=10;
    }
    t=1;
    for(i=0;i<m;i++)//����ڶ�����
    {
        r2+=b1[i]*t;
        t*=10;
    }
    r=r1+r2;
    for(i=0;r!=0;i++)//����͵ĸ�������
    {
        c1[i]=r%10;
        r=r/10;
    }
    p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = c1[0];
	head = NULL;
	for (j=0; j <i; j++)//��������
	{
		if (j == 0)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = c1[j+1];
	}
	p2->next = NULL;
	return head;
}

//4.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
	int val;
	struct ListNode* next;
};

int main()
{
	struct ListNode*head = NULL, * p1, * p2;
	int n = 0, a[100],i;
	char c;
	while (1)//������������
	{
		scanf("%c", &c);
		if(c>=48&&c<=57)
            a[n]=c-48;
        else break;
        n++;
		scanf("%c", &c);
		if (c == '-') scanf("%c", &c);
		else break;
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	for (i=0; i < n; i++)//��������
	{
		if (i == 0)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
	struct ListNode* oddEvenList(struct ListNode*head);
	struct ListNode* p = oddEvenList(head);
	while(p!=NULL)//�������
    {
        printf("%d->",p->val);
        p=p->next;
    }
    printf("NULL");
	return 0;
}

struct ListNode* oddEvenList(struct ListNode*head)
{
	struct ListNode*p,*p1,*p2;
	int a1[100],b1[100],c1[100],n=0,i,j,n1=0,n2=0;
	p=head;
	while (p!=NULL)//������������
	{
		a1[n]=p->val;
		p=p->next;
		n++;
	}
	for(i=0;i<n;)//ȡ������������
    {
        b1[n1]=a1[i];
        n1++;
        i+=2;
    }
    for(i=1;i<n;)//ȡ��ż��������
    {
        c1[n2]=a1[i];
        n2++;
        i+=2;
    }
    p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = b1[0];
	head = NULL;
	for (j=1; j <=(n1+n2); j++)//��������
	{
		if (j == 1)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		if(j<n1)
		p1->val = b1[j];
		else
            p1->val=c1[j-n1];
	}
	p2->next = NULL;
	return head;
}

//5.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
    int val;
    struct ListNode*next;
};

int main()
{
    struct ListNode *head,*p1,*p2;
    int n = 0, a[100],i,x,flag=0;
	char c;
	scanf("head=%d", &a[n]);n++;
	while (1)//������������
	{
		scanf("%c", &c);
		if (c == '-')
        {
            scanf("%c", &c);
            scanf("%d",&a[n]);
            n++;
        }
		else{
            scanf("x=%d",&x);
            break;
		}
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	for (i=0; i < n; i++)//��������
	{
		if (i == 0)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
    struct ListNode*partition(struct ListNode* head, int x);
    struct ListNode*p=partition(head,x);
    while (p != NULL)//�������
	{
		if(flag==0)printf("%d", p->val);
		else
		printf("->%d", p->val);
		p = p->next;
		flag++;
	}
    return 0;
}

struct ListNode*partition(struct ListNode* head, int x)
{
    struct ListNode*p,*q,*p1,*p2;
    int a[100],b[100],n=0,m=0,i,j;
    p=head;
    while(p!=NULL)
    {
        if(p->val<x)//�������С��x���ŵ�a������
        {
            a[n]=p->val;
            n++;
        }
        else{
            b[m]=p->val;//������ݴ��ڵ���x���ŵ�b������
            m++;
        }
        p=p->next;
    }
    p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	q = NULL;
	for (j=1; j <=(n+m); j++)//��������
	{
		if (j == 1)q = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		if(j<n)
		p1->val = a[j];
		else
            p1->val=b[j-n];
	}
	p2->next = NULL;
    return q;
}

//6.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
    int val;
    struct ListNode*next;
};

int main()
{
    struct ListNode *head,*p1,*p2;
    int n = 0, a[100],i,x,flag=0;
	char c;
	scanf("head=[%d", &a[n]);n++;
	while (1)//������������
	{
		scanf("%c", &c);
		if (c == ',')
        {
            scanf("%d",&a[n]);
            n++;
        }
		else{
            break;
		}
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	for (i=0; i < n; i++)//��������
	{
		if (i == 0)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
    struct ListNode*deleteZero(struct ListNode* head);
    struct ListNode*p=deleteZero(head);
    while (p != NULL)//�������
	{
		if(flag==0)printf("[%d", p->val);
		else
		printf(",%d", p->val);
		p = p->next;
		flag++;
	}
	printf("]");
    return 0;
}

struct ListNode*deleteZero(struct ListNode* head)
{
    struct ListNode*p,*q,*p1,*p2,*temp,*pre;
    temp=(struct ListNode*)malloc(LEN);
    int num=0,flag=0,i,j;
    temp->next=head;
    pre=temp;
    p=head;
    while(p!=NULL)//ɾȥ������ֵΪ0�Ľ��
    {
        if(p->val==0)
        {
            pre->next=p->next;
            p=pre->next;
        }
        else{
            pre=pre->next;
            p=p->next;
        }
    }
    pre=temp;
    p=pre->next;
    while(p!=NULL)//ɾȥ����������Ϊ0�Ľ��
    {
        num=p->val;
        flag=0;
        q=p->next;
        while(q!=NULL)
        {
            num=q->val+num;
            if(num==0)
            {
                pre->next=q->next;
                p=pre->next;
                flag=1;
                break;
            }
            q=q->next;
        }
        if(flag==0)
        {
            pre=pre->next;
            p=p->next;
        }
    }
    return temp->next;
}

//7.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
    int val;
    struct ListNode*next;
};

int main()
{
    struct ListNode *head1,*head2,*p1,*p2;
    int n = 0,m=0, a[100],b[100],i,flag=0;
	char c;
	while (1)//�����һ����������
	{
	    scanf("%d", &a[n]);
	    n++;
	    scanf("%c",&c);
	    if (c == '-') scanf("%c", &c);
	    if(c==',')break;
	}
	while (1)//����ڶ�����������
	{
	    scanf("%d", &b[m]);
	    m++;
	    scanf("%c",&c);
	    if (c == '-') scanf("%c", &c);
	    else break;
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	for (i=0; i < n; i++)//������һ������
	{
		if (i == 0)head1 = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = b[0];
	for (i=0; i < n; i++)//�����ڶ�������
	{
		if (i == 0)head2 = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = b[i+1];
	}
	p2->next = NULL;
    struct ListNode*mergeTwoLists(struct ListNode* l1,struct ListNode* l2);
    struct ListNode*p=mergeTwoLists(head1,head2);
    while (p != NULL)//�������
	{
		if(flag==0)printf("%d", p->val);
		else
		printf("->%d", p->val);
		p = p->next;
		flag++;
	}
    return 0;
}

struct ListNode*mergeTwoLists(struct ListNode* l1,struct ListNode* l2)
{
    struct ListNode*p,*q,*p1,*p2,*temp;
    int num[1000],i,j,n=0;
    p=l1;
    q=l2;
    while(p!=NULL&&q!=NULL)//�����Ƚ�����������ǰ��ֵ�Ĵ�С
    {
        if(p->val<q->val)
            {
                num[n]=p->val;
                p=p->next;
            }
        else{
                num[n]=q->val;
                q=q->next;
        }
        n++;
    }
    if(p==NULL&&q!=NULL)//����ڶ���������û�б����꣬��ʣ�µ���������������
    {
        while(q!=NULL)
        {
            num[n]=q->val;
            n++;
            q=q->next;
        }
    }
    else if(q==NULL&&p!=NULL)//�����һ��������û�б����꣬��ʣ�µ���������������
    {
        while(p!=NULL)
        {
            num[n]=p->val;
            n++;
            p=p->next;
        }
    }
    p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = num[0];
	for (i=0; i < n; i++)//��������
	{
		if (i == 0)temp = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = num[i+1];
	}
	p2->next = NULL;
    return temp;
}

//8.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
	int val;
	struct ListNode* next;
};

int main()
{
	struct ListNode*head1 = NULL,*head2=NULL, * p1, * p2;
	int n = 0,m=0, a[100],b[100],c[100],flag=0,i;
	char ch;
	while (1)//�����һ����������
	{
	    scanf("%c", &ch);
	    if (ch == '-') scanf("%c", &ch);
	    if(ch==')')break;
		scanf("%d", &a[n]); n++;
	}
	scanf("%c",&ch);
	while (1)//����ڶ�����������
	{
	    scanf("%c", &ch);
	    if (ch == '-') scanf("%c", &ch);
	    if(ch==')')break;
		scanf("%d", &b[m]); m++;
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	for (i=0; i < n; i++)//������һ������
	{
		if (i == 0)head1 = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = b[0];
	for (i=0; i < m; i++)//�����ڶ�������
	{
		if (i == 0)head2 = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = b[i+1];
	}
	p2->next = NULL;
	struct ListNode* addTwoNumbers(struct ListNode* l1,struct ListNode* l2);
	struct ListNode* p = addTwoNumbers(head1,head2);
	while (p != NULL)//�������
	{
		if(flag==0)printf("%d", p->val);
		else
		printf("->%d", p->val);
		p = p->next;
		flag++;
	}
	return 0;
}

struct ListNode* addTwoNumbers(struct ListNode* l1,struct ListNode* l2)
{
	struct ListNode*p,*q,*head,*p1,*p2;
	int a1[100],b1[100],c1[100],n=0,m=0,i,j,r1=0,r2=0,r,t=1;
	p=l1;q=l2;
	while (p!=NULL)//�����һ����������
	{
		a1[n]=p->val;
		p=p->next;
		n++;
	}
	while (q!=NULL)//����ڶ�����������
	{
		b1[m]=q->val;
		q=q->next;
		m++;
	}
	for(i=n-1;i>=0;i--)//�����һ����
    {
        r1+=a1[i]*t;
        t*=10;
    }
    t=1;
    for(i=m-1;i>=0;i--)//����ڶ�����
    {
        r2+=b1[i]*t;
        t*=10;
    }
    r=r1+r2;
    for(i=0;r!=0;i++)//����͵ĸ�������
    {
        c1[i]=r%10;
        r=r/10;
    }
    p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = c1[i-1];
	head = NULL;
	for (j=i-1; j >=0; j--)//��������
	{
		if (j == i-1)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = c1[j-1];
	}
	p2->next = NULL;
	return head;
}

//9.
#include<stdio.h>
#include<stdlib.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
	int val;
	struct ListNode* next;
};

int main()
{
	struct ListNode* head = NULL, * p1, * p2;
	int n = 0, a[100],flag=0,i;
	char c;
	while (1)//������������
	{
		scanf("%d", &a[n]); n++;
		scanf("%c", &c);
		if (c == '-') scanf("%c", &c);
		else break;
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	head = NULL;
	for (i=0; i < n; i++)//��������
	{
		if (i == 0)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
	struct ListNode* deleteDuplicates(struct ListNode* head);
	struct ListNode* p = deleteDuplicates(head);
	while (p != NULL)//�������
	{
		if(flag==0)printf("%d", p->val);
		else
		printf("->%d", p->val);
		p = p->next;
		flag++;
	}
	return 0;
}

struct ListNode* deleteDuplicates(struct ListNode* head)
{
	struct ListNode*cur,*pre,*temp;
	temp=(struct ListNode*)malloc(LEN);
	int flag=0;
	temp->next=head;
	pre=temp;
	cur=head;
	while (cur!=NULL)
	{
		while((cur->next!=NULL)&&(cur->val==cur->next->val))//���ظ�Ԫ�ؾ�һֱ���±���
        {
            cur=cur->next;
            flag=1;
        }
        if(flag==1)//ɾȥ�����ظ�Ԫ��
        {
            pre->next=cur->next;
            cur=pre->next;
            flag=0;
        }
        else{               //û���ظ�Ԫ�ؾͼ������±���
            pre=pre->next;
            cur=cur->next;
        }
	}
	return temp->next;
}

//10.
#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#define LEN sizeof(struct ListNode)
struct ListNode
{
	int val;
	struct ListNode* next;
};

int main()
{
	struct ListNode* head = NULL, * p1, * p2;
	int n = 0, a[100],flag,i;
	char c;
	while (1)//������������
	{
		scanf("%d", &a[n]); n++;
		scanf("%c", &c);
		if (c == '-') scanf("%c", &c);
		else break;
	}
	p1 = p2 = (struct ListNode*)malloc(LEN);
	p1->val = a[0];
	head = NULL;
	for (i=0; i < n; i++)//��������
	{
		if (i == 0)head = p1;
		else p2->next = p1;
		p2 = p1;
		p1 = (struct ListNode*)malloc(LEN);
		p1->val = a[i+1];
	}
	p2->next = NULL;
	bool isPalindrome(struct ListNode* head);
	flag=isPalindrome(head);
	if(flag==0)printf("false");//������
	else printf("true");
	return 0;
}

bool isPalindrome(struct ListNode* head)
{
	struct ListNode*p;
	int flag=1,a[100],n=0,i;
	p=head;
    while (p!=NULL)//������������
	{
		a[n]=p->val;
		p=p->next;
		n++;
	}
	for(i=0;i<=n/2;i++)//�ж��Ƿ����
    {
        if(a[i]!=a[n-1-i])
        {
            flag=0;
            break;
        }
    }
	return flag;
}
